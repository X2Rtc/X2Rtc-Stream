## Scripts for building SRT for Android

See [Building SRT for Android](../../docs/build/build-android.md) for the instructions.
