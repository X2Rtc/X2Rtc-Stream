Testing
=======

This directory contains applications used for testing and development only.

They may contain experimental versions or not fully functioning features.

Every application has its own individual Manifest file (`*.maf`), which defines
of which source files particular application comprises. They may be contained
either in the same directory, or in any other subproject.
